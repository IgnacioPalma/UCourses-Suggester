# UCourses-Suggester
Recommender system for the courses of the Pontifical Catholic University of Chile (UC).
